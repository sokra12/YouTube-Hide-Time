/* Protected Build - Copyright (c) 2026 Sokra701s (Ko-fi: D1D71L76R7). All Rights Reserved. Unauthorized copying prohibited. */
const _0x0a11 = [
 'masterEnabled',
 'hideThumbnails',
 'hidePlayerTime',
 'hideProgressBar',
 'hideHoverPreview',
 'hideTimestamps',
 'clockEnabled',
 'clockShowCity',
 'clockFormat24',
 'ytHideShorts',
 'ytHideSidebar',
 'ytHideComments',
 'ytHideEndcards',
 'ytRoundedThumbnails'
];
const _0x0a12 = [
 'clockDisplayMode',
 'clockStyle',
 'clockCalendarType',
 'ytGridCols',
 'ytAccentColor',
 'ytBgTheme'
];
const _0x0a10 = {
 masterEnabled: true,
 hideThumbnails: true,
 hidePlayerTime: true,
 hideProgressBar: false,
 hideHoverPreview: true,
 hideTimestamps: false,
 clockEnabled: false,
 clockTimezone: 'Asia/Riyadh',
 clockCountryName: 'السعودية - الرياض',
 clockDisplayMode: 'both', // 'both' | 'time_only' | 'date_only'
 clockCalendarType: 'hijri_greg', // 'hijri_greg' | 'hijri' | 'gregorian'
 clockShowCity: true,
 clockStyle: 'glass-pill', // 'glass-pill' | 'minimal' | 'stacked-card' | 'neon' | 'gold' | 'outline'
 clockScale: 100, // 65% to 185%
 clockOpacity: 35, // 0% (transparent background) to 95%
 clockTextOpacity: 90, // 15% to 100%
 clockFormat24: false,
 ytHideShorts: false,
 ytHideSidebar: false,
 ytHideComments: false,
 ytHideEndcards: false,
 ytRoundedThumbnails: false,
 ytGridCols: 'default',
 ytAccentColor: 'default',
 ytBgTheme: 'default'
};
let _0x0a17 = { ..._0x0a10 };
const _0x0a13 = [
 { tz: 'Asia/Riyadh', name: 'السعودية - الرياض / مكة المكرمة (Saudi Arabia)' },
 { tz: 'Asia/Dubai', name: 'الإمارات - دبي / أبوظبي (UAE)' },
 { tz: 'Asia/Kuwait', name: 'الكويت - مدينة الكويت (Kuwait)' },
 { tz: 'Asia/Qatar', name: 'قطر - الدوحة (Qatar)' },
 { tz: 'Asia/Bahrain', name: 'البحرين - المنامة (Bahrain)' },
 { tz: 'Asia/Muscat', name: 'عُمان - مسقط (Oman)' },
 { tz: 'Africa/Cairo', name: 'مصر - القاهرة (Egypt)' },
 { tz: 'Asia/Amman', name: 'الأردن - عمّان (Jordan)' },
 { tz: 'Asia/Baghdad', name: 'العراق - بغداد (Iraq)' },
 { tz: 'Asia/Damascus', name: 'سوريا - دمشق (Syria)' },
 { tz: 'Asia/Beirut', name: 'لبنان - بيروت (Lebanon)' },
 { tz: 'Asia/Jerusalem', name: 'فلسطين - القدس (Palestine)' },
 { tz: 'Asia/Aden', name: 'اليمن - صنعاء / عدن (Yemen)' },
 { tz: 'Africa/Casablanca', name: 'المغرب - الرباط / الدار البيضاء (Morocco)' },
 { tz: 'Africa/Algiers', name: 'الجزائر - الجزائر (Algeria)' },
 { tz: 'Africa/Tunis', name: 'تونس - تونس (Tunisia)' },
 { tz: 'Africa/Tripoli', name: 'ليبيا - طرابلس (Libya)' },
 { tz: 'Africa/Khartoum', name: 'السودان - الخرطوم (Sudan)' },
 { tz: 'Europe/Istanbul', name: 'تركيا - إسطنبول (Turkey)' },
 { tz: 'Europe/London', name: 'بريطانيا - لندن (UK - London)' },
 { tz: 'Europe/Paris', name: 'فرنسا - باريس (France - Paris)' },
 { tz: 'Europe/Berlin', name: 'ألمانيا - برلين (Germany - Berlin)' },
 { tz: 'Europe/Madrid', name: 'إسبانيا - مدريد (Spain - Madrid)' },
 { tz: 'Europe/Rome', name: 'إيطاليا - روما (Italy - Rome)' },
 { tz: 'Europe/Moscow', name: 'روسيا - موسكو (Russia - Moscow)' },
 { tz: 'America/New_York', name: 'أمريكا - نيويورك / واشنطن (USA - New York)' },
 { tz: 'America/Chicago', name: 'أمريكا - شيكاغو (USA - Chicago)' },
 { tz: 'America/Los_Angeles', name: 'أمريكا - لوس أنجلوس (USA - Los Angeles)' },
 { tz: 'America/Toronto', name: 'كندا - تورونتو (Canada - Toronto)' },
 { tz: 'America/Sao_Paulo', name: 'البرازيل - ساو باولو (Brazil)' },
 { tz: 'Asia/Tokyo', name: 'اليابان - طوكيو (Japan - Tokyo)' },
 { tz: 'Asia/Seoul', name: 'كوريا الجنوبية - سيول (South Korea)' },
 { tz: 'Asia/Shanghai', name: 'الصين - بكين / شنغهاي (China)' },
 { tz: 'Asia/Hong_Kong', name: 'هونغ كونغ (Hong Kong)' },
 { tz: 'Asia/Singapore', name: 'سنغافورة (Singapore)' },
 { tz: 'Asia/Kuala_Lumpur', name: 'ماليزيا - كوالالمبور (Malaysia)' },
 { tz: 'Asia/Jakarta', name: 'إندونيسيا - جاكرتا (Indonesia)' },
 { tz: 'Asia/Kolkata', name: 'الهند - نيودلهي / مومباي (India)' },
 { tz: 'Asia/Karachi', name: 'باكستان - كراتشي / إسلام آباد (Pakistan)' },
 { tz: 'Australia/Sydney', name: 'أستراليا - سيدني (Australia - Sydney)' },
 { tz: 'Pacific/Auckland', name: 'نيوزيلندا - أوكلاند (New Zealand)' },
 { tz: 'Africa/Johannesburg', name: 'جنوب أفريقيا - جوهانسبرغ (South Africa)' }
];
function _0x0a1e() {
 const map = new Map();
 _0x0a13.forEach(item => map.set(item.tz, item.name));
 if (typeof Intl !== 'undefined' && typeof Intl.supportedValuesOf === 'function') {
 try {
 const allZones = Intl.supportedValuesOf('timeZone');
 allZones.forEach(tz => {
 if (!map.has(tz)) {
 const readable = tz.replace(/_/g, ' ').replace(/\//g, ' - ');
 map.set(tz, readable);
 }
 });
 } catch (e) {}
 }
 return Array.from(map.entries()).map(([tz, name]) => ({ tz, name }));
}
const _0x0a14 = _0x0a1e();
document.querySelectorAll('.tab-btn').forEach(btn => {
 btn.addEventListener('click', () => {
 document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
 document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
 btn.classList.add('active');
 const panel = document.getElementById(btn.dataset.tab);
 if (panel) panel.classList.add('active');
 });
});
document.querySelectorAll('[data-subtab]').forEach(btn => {
 btn.addEventListener('click', () => {
 const parent = btn.closest('.tab-panel');
 parent.querySelectorAll('[data-subtab]').forEach(b => b.classList.remove('active'));
 parent.querySelectorAll('.subtab-panel').forEach(p => p.classList.remove('active'));
 btn.classList.add('active');
 const target = document.getElementById(btn.dataset.subtab);
 if (target) target.classList.add('active');
 });
});
document.querySelectorAll('[data-datetab]').forEach(btn => {
 btn.addEventListener('click', () => {
 const parent = btn.closest('.card-box');
 parent.querySelectorAll('[data-datetab]').forEach(b => b.classList.remove('active'));
 parent.querySelectorAll('.datetab-panel').forEach(p => p.classList.remove('active'));
 btn.classList.add('active');
 const target = document.getElementById(btn.dataset.datetab);
 if (target) target.classList.add('active');
 });
});
const statusMessage = document.getElementById('statusMessage');
let statusTimeout = null;
function _0x0a32(text) {
 if (!statusMessage) return;
 statusMessage.textContent = text;
 statusMessage.style.color = '#38BDF8';
 clearTimeout(statusTimeout);
 statusTimeout = setTimeout(() => {
 statusMessage.textContent = "التغييرات تطبق فورياً على جميع المقاطع";
 statusMessage.style.color = '#64748B';
 }, 1800);
}
function _0x0a1f(partial) {
 _0x0a17 = { ..._0x0a17, ...partial };
 if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
 chrome.storage.sync.set(_0x0a17, () => {
 _0x0a32("تم حفظ الإعدادات وتطبيقها فورياً ✓");
 });
 }
}
function _0x0a20() {
 const applyToUI = (stored) => {
 _0x0a17 = { ..._0x0a10, ...(stored || {}) };
 _0x0a11.forEach(field => {
 const el = document.getElementById(field);
 if (el) el.checked = Boolean(_0x0a17[field]);
 });
 _0x0a12.forEach(field => {
 const el = document.getElementById(field);
 if (el && _0x0a17[field] !== undefined) {
 el.value = _0x0a17[field];
 }
 });
 const scaleSlider = document.getElementById('clockScale');
 const scaleLabel = document.getElementById('scaleValLabel');
 const scaleVal = _0x0a17.clockScale ?? 100;
 if (scaleSlider) scaleSlider.value = scaleVal;
 if (scaleLabel) scaleLabel.textContent = `${scaleVal}%`;
 const opacitySlider = document.getElementById('clockOpacity');
 const opacityLabel = document.getElementById('opacityValLabel');
 const opVal = _0x0a17.clockOpacity ?? 35;
 if (opacitySlider) opacitySlider.value = opVal;
 if (opacityLabel) opacityLabel.textContent = `${opVal}%`;
 const textOpSlider = document.getElementById('clockTextOpacity');
 const textOpLabel = document.getElementById('textOpacityValLabel');
 const textOpVal = _0x0a17.clockTextOpacity ?? 90;
 if (textOpSlider) textOpSlider.value = textOpVal;
 if (textOpLabel) textOpLabel.textContent = `${textOpVal}%`;
 const settingsList = document.getElementById('settingsList');
 if (settingsList) {
 settingsList.classList.toggle('disabled', !_0x0a17.masterEnabled);
 }
 _0x0a23(document.getElementById('countrySearchInput')?.value || '');
 _0x0a24();
 };
 if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
 chrome.storage.sync.get(_0x0a10, applyToUI);
 } else {
 applyToUI(_0x0a10);
 }
}
_0x0a11.forEach(field => {
 const el = document.getElementById(field);
 if (!el) return;
 el.addEventListener('change', () => {
 if (field === 'masterEnabled') {
 const settingsList = document.getElementById('settingsList');
 if (settingsList) settingsList.classList.toggle('disabled', !el.checked);
 }
 _0x0a1f({ [field]: el.checked });
 if (field === 'clockFormat24') {
 _0x0a23(document.getElementById('countrySearchInput')?.value || '');
 _0x0a24();
 }
 });
});
_0x0a12.forEach(field => {
 const el = document.getElementById(field);
 if (!el) return;
 el.addEventListener('change', () => {
 _0x0a1f({ [field]: el.value });
 _0x0a24();
 });
});
const scaleSlider = document.getElementById('clockScale');
if (scaleSlider) {
 scaleSlider.addEventListener('input', () => {
 const val = Number(scaleSlider.value);
 const label = document.getElementById('scaleValLabel');
 if (label) label.textContent = `${val}%`;
 _0x0a1f({ clockScale: val });
 });
}
const opacitySlider = document.getElementById('clockOpacity');
if (opacitySlider) {
 opacitySlider.addEventListener('input', () => {
 const val = Number(opacitySlider.value);
 const label = document.getElementById('opacityValLabel');
 if (label) label.textContent = `${val}%`;
 _0x0a1f({ clockOpacity: val });
 });
}
const textOpacitySlider = document.getElementById('clockTextOpacity');
if (textOpacitySlider) {
 textOpacitySlider.addEventListener('input', () => {
 const val = Number(textOpacitySlider.value);
 const label = document.getElementById('textOpacityValLabel');
 if (label) label.textContent = `${val}%`;
 _0x0a1f({ clockTextOpacity: val });
 });
}
const countrySearchInput = document.getElementById('countrySearchInput');
const countryListContainer = document.getElementById('countryListContainer');
function _0x0a21(tz, use24) {
 try {
 return new Intl.DateTimeFormat('en-US', {
 timeZone: tz,
 hour: '2-digit',
 minute: '2-digit',
 second: '2-digit',
 hour12: !use24
 }).format(new Date());
 } catch (e) {
 return '--:--';
 }
}
function _0x0a22(tz, calType) {
 try {
 const now = new Date();
 const hijri = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
 timeZone: tz,
 day: 'numeric',
 month: 'short',
 year: 'numeric'
 }).format(now);
 const greg = new Intl.DateTimeFormat('en-GB', {
 timeZone: tz,
 day: '2-digit',
 month: '2-digit',
 year: 'numeric'
 }).format(now);
 if (calType === 'hijri') return hijri;
 if (calType === 'gregorian') return greg;
 return `${hijri} | ${greg}`;
 } catch (e) {
 return '--';
 }
}
function _0x0a23(query = '') {
 if (!countryListContainer) return;
 const q = query.trim().toLowerCase();
 const filtered = _0x0a14.filter(item =>
 !q || item.name.toLowerCase().includes(q) || item.tz.toLowerCase().includes(q)
 ).slice(0, 60);
 countryListContainer.innerHTML = '';
 filtered.forEach(item => {
 const div = document.createElement('div');
 div.className = 'country-item' + (item.tz === _0x0a17.clockTimezone ? ' selected' : '');
 const timeNow = _0x0a21(item.tz, _0x0a17.clockFormat24);
 div.innerHTML = `
 <span>${item.name}</span>
 <span class="country-item-time">${timeNow}</span>
 `;
 div.addEventListener('click', () => {
 const shortLabel = item.name.split('(')[0].trim();
 _0x0a1f({
 clockTimezone: item.tz,
 clockCountryName: shortLabel
 });
 _0x0a23(countrySearchInput?.value || '');
 _0x0a24();
 });
 countryListContainer.appendChild(div);
 });
}
function _0x0a24() {
 const labelEl = document.getElementById('selectedCityLabel');
 const timeEl = document.getElementById('selectedCityLiveTime');
 const dateEl = document.getElementById('selectedCityLiveDate');
 const tz = _0x0a17.clockTimezone || 'Asia/Riyadh';
 if (labelEl) labelEl.textContent = _0x0a17.clockCountryName || 'السعودية - الرياض';
 if (timeEl) {
 timeEl.textContent = _0x0a21(tz, _0x0a17.clockFormat24);
 }
 if (dateEl) {
 dateEl.textContent = _0x0a22(tz, _0x0a17.clockCalendarType || 'hijri_greg');
 }
}
if (countrySearchInput) {
 countrySearchInput.addEventListener('input', () => {
 _0x0a23(countrySearchInput.value);
 });
}
setInterval(_0x0a24, 1000);
function _0x0a25() {
 const amount = parseFloat(document.getElementById('taxAmount')?.value) || 0;
 const rate = parseFloat(document.getElementById('taxRate')?.value) || 0;
 const mode = document.getElementById('taxMode')?.value || 'exclude';
 let net = 0, tax = 0, total = 0;
 if (mode === 'exclude') {
 net = amount;
 tax = amount * (rate / 100);
 total = net + tax;
 } else {
 total = amount;
 net = amount / (1 + rate / 100);
 tax = total - net;
 }
 document.getElementById('taxNetRes').textContent = net.toFixed(2);
 document.getElementById('taxValRes').textContent = tax.toFixed(2);
 document.getElementById('taxTotalRes').textContent = total.toFixed(2);
}
['taxAmount', 'taxRate', 'taxMode'].forEach(id => {
 document.getElementById(id)?.addEventListener('input', _0x0a25);
 document.getElementById(id)?.addEventListener('change', _0x0a25);
});
function _0x0a26() {
 const orig = parseFloat(document.getElementById('discOriginal')?.value) || 0;
 const d1 = parseFloat(document.getElementById('discPercent')?.value) || 0;
 const d2 = parseFloat(document.getElementById('discExtra')?.value) || 0;
 const after1 = orig * (1 - d1 / 100);
 const finalPrice = after1 * (1 - d2 / 100);
 const saved = orig - finalPrice;
 document.getElementById('discSavedRes').textContent = saved.toFixed(2);
 document.getElementById('discFinalRes').textContent = finalPrice.toFixed(2);
}
['discOriginal', 'discPercent', 'discExtra'].forEach(id => {
 document.getElementById(id)?.addEventListener('input', _0x0a26);
});
function _0x0a27() {
 const r1 = parseFloat(document.getElementById('pct1Rate')?.value);
 const t1 = parseFloat(document.getElementById('pct1Total')?.value);
 document.getElementById('pct1Res').textContent =
 (!isNaN(r1) && !isNaN(t1)) ? ((r1 / 100) * t1).toFixed(2) : '0';
 const p2 = parseFloat(document.getElementById('pct2Part')?.value);
 const w2 = parseFloat(document.getElementById('pct2Whole')?.value);
 document.getElementById('pct2Res').textContent =
 (!isNaN(p2) && !isNaN(w2) && w2 !== 0) ? ((p2 / w2) * 100).toFixed(2) + '%' : '0%';
 const o3 = parseFloat(document.getElementById('pct3Old')?.value);
 const n3 = parseFloat(document.getElementById('pct3New')?.value);
 if (!isNaN(o3) && !isNaN(n3) && o3 !== 0) {
 const diff = ((n3 - o3) / Math.abs(o3)) * 100;
 const sign = diff > 0 ? '+' : '';
 document.getElementById('pct3Res').textContent = `${sign}${diff.toFixed(2)}%`;
 } else {
 document.getElementById('pct3Res').textContent = '0%';
 }
}
['pct1Rate', 'pct1Total', 'pct2Part', 'pct2Whole', 'pct3Old', 'pct3New'].forEach(id => {
 document.getElementById(id)?.addEventListener('input', _0x0a27);
});
const _0x0a16 = [
 { code: 'SAR', name: 'ريال سعودي (SAR)', rateToUSD: 3.75 },
 { code: 'USD', name: 'دولار أمريكي (USD)', rateToUSD: 1.00 },
 { code: 'AED', name: 'درهم إماراتي (AED)', rateToUSD: 3.6725 },
 { code: 'KWD', name: 'دينار كويتي (KWD)', rateToUSD: 0.307 },
 { code: 'QAR', name: 'ريال قطري (QAR)', rateToUSD: 3.64 },
 { code: 'BHD', name: 'دينار بحريني (BHD)', rateToUSD: 0.376 },
 { code: 'OMR', name: 'ريال عماني (OMR)', rateToUSD: 0.385 },
 { code: 'EGP', name: 'جنيه مصري (EGP)', rateToUSD: 49.20 },
 { code: 'JOD', name: 'دينار أردني (JOD)', rateToUSD: 0.709 },
 { code: 'EUR', name: 'يورو أوروبي (EUR)', rateToUSD: 0.92 },
 { code: 'GBP', name: 'جنيه إسترليني (GBP)', rateToUSD: 0.79 },
 { code: 'TRY', name: 'ليرة تركية (TRY)', rateToUSD: 34.30 },
 { code: 'JPY', name: 'ين ياباني (JPY)', rateToUSD: 152.50 },
 { code: 'CNY', name: 'يوان صيني (CNY)', rateToUSD: 7.18 },
 { code: 'INR', name: 'روبية هندية (INR)', rateToUSD: 84.10 },
 { code: 'CAD', name: 'دولار كندي (CAD)', rateToUSD: 1.39 },
 { code: 'AUD', name: 'دولار أسترالي (AUD)', rateToUSD: 1.52 },
 { code: 'CHF', name: 'فرنك سويسري (CHF)', rateToUSD: 0.87 }
];
let liveRates = {};
_0x0a16.forEach(c => { liveRates[c.code] = c.rateToUSD; });
function _0x0a28() {
 const fromSel = document.getElementById('currFrom');
 const toSel = document.getElementById('currTo');
 if (!fromSel || !toSel) return;
 _0x0a16.forEach(c => {
 fromSel.add(new Option(c.name, c.code));
 toSel.add(new Option(c.name, c.code));
 });
 fromSel.value = 'USD';
 toSel.value = 'SAR';
 fetch('https://open.er-api.com/v6/latest/USD')
 .then(r => r.json())
 .then(data => {
 if (data && data.rates) {
 liveRates = { ...liveRates, ...data.rates };
 const statusEl = document.getElementById('currencyRateStatus');
 if (statusEl) statusEl.textContent = 'أسعار صرف محدّثة تلقائياً ✓';
 _0x0a29();
 }
 })
 .catch(() => {});
 _0x0a29();
}
function _0x0a29() {
 const amt = parseFloat(document.getElementById('currAmount')?.value) || 0;
 const from = document.getElementById('currFrom')?.value || 'USD';
 const to = document.getElementById('currTo')?.value || 'SAR';
 const rFrom = liveRates[from] || 1;
 const rTo = liveRates[to] || 1;
 const inUSD = amt / rFrom;
 const result = inUSD * rTo;
 const unitRate = rTo / rFrom;
 document.getElementById('currResultVal').textContent = `${result.toFixed(2)} ${to}`;
 document.getElementById('currUnitRateNote').textContent = `1 ${from} = ${unitRate.toFixed(4)} ${to}`;
}
['currAmount', 'currFrom', 'currTo'].forEach(id => {
 document.getElementById(id)?.addEventListener('input', _0x0a29);
 document.getElementById(id)?.addEventListener('change', _0x0a29);
});
document.getElementById('currSwapBtn')?.addEventListener('click', () => {
 const fromSel = document.getElementById('currFrom');
 const toSel = document.getElementById('currTo');
 const tmp = fromSel.value;
 fromSel.value = toSel.value;
 toSel.value = tmp;
 _0x0a29();
});
function _0x0a2a(date) {
 try {
 return new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
 day: 'numeric',
 month: 'long',
 year: 'numeric'
 }).format(date);
 } catch (e) {
 return '--';
 }
}
function _0x0a2b(date) {
 try {
 return new Intl.DateTimeFormat('ar-EG', {
 day: 'numeric',
 month: 'long',
 year: 'numeric'
 }).format(date);
 } catch (e) {
 return date.toLocaleDateString();
 }
}
function _0x0a2c(date) {
 const parts = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', {
 day: 'numeric',
 month: 'numeric',
 year: 'numeric'
 }).formatToParts(date);
 let y = 1448, m = 1, d = 1;
 parts.forEach(p => {
 if (p.type === 'year') y = parseInt(p.value, 10);
 if (p.type === 'month') m = parseInt(p.value, 10);
 if (p.type === 'day') d = parseInt(p.value, 10);
 });
 return { y, m, d };
}
function _0x0a2d(hy, hm, hd) {
 const approxYear = Math.floor(hy * 0.970224 + 621.57);
 let cursor = new Date(Date.UTC(approxYear, hm - 1, Math.min(hd, 28), 12, 0, 0));
 for (let i = 0; i < 450; i++) {
 const { y, m, d } = _0x0a2c(cursor);
 const diffDays = (hy - y) * 354 + (hm - m) * 29.5 + (hd - d);
 if (y === hy && m === hm && d === hd) {
 return cursor;
 }
 const step = Math.round(diffDays);
 cursor.setUTCDate(cursor.getUTCDate() + (step === 0 ? (hy > y || hm > m || hd > d ? 1 : -1) : step));
 }
 return cursor;
}
function _0x0a2e() {
 const now = new Date();
 const dayName = new Intl.DateTimeFormat('ar-SA', { weekday: 'long' }).format(now);
 document.getElementById('todayDayName').textContent = dayName;
 document.getElementById('todayHijri').textContent = _0x0a2a(now);
 document.getElementById('todayGregorian').textContent = _0x0a2b(now);
 const isoToday = now.toISOString().split('T')[0];
 const g2hInput = document.getElementById('g2hInput');
 if (g2hInput) {
 g2hInput.value = isoToday;
 _0x0a2f();
 g2hInput.addEventListener('input', _0x0a2f);
 }
 const hParts = _0x0a2c(now);
 const hDay = document.getElementById('hDay');
 const hMonth = document.getElementById('hMonth');
 const hYear = document.getElementById('hYear');
 if (hDay && hMonth && hYear) {
 hDay.value = hParts.d;
 hMonth.value = hParts.m;
 hYear.value = hParts.y;
 _0x0a30();
 [hDay, hMonth, hYear].forEach(el => {
 el.addEventListener('input', _0x0a30);
 el.addEventListener('change', _0x0a30);
 });
 }
 const diffStart = document.getElementById('diffStart');
 const diffEnd = document.getElementById('diffEnd');
 if (diffStart && diffEnd) {
 diffStart.value = isoToday;
 diffEnd.value = isoToday;
 _0x0a31();
 [diffStart, diffEnd].forEach(el => el.addEventListener('input', _0x0a31));
 }
}
function _0x0a2f() {
 const val = document.getElementById('g2hInput')?.value;
 if (!val) return;
 const d = new Date(val + 'T12:00:00');
 const dayName = new Intl.DateTimeFormat('ar-SA', { weekday: 'long' }).format(d);
 document.getElementById('g2hResult').textContent = `${dayName}، ${_0x0a2a(d)}`;
}
function _0x0a30() {
 const hd = parseInt(document.getElementById('hDay')?.value, 10) || 1;
 const hm = parseInt(document.getElementById('hMonth')?.value, 10) || 1;
 const hy = parseInt(document.getElementById('hYear')?.value, 10) || 1448;
 const gregDate = _0x0a2d(hy, hm, hd);
 const dayName = new Intl.DateTimeFormat('ar-SA', { weekday: 'long' }).format(gregDate);
 const iso = gregDate.toISOString().split('T')[0];
 document.getElementById('h2gResult').textContent = `${dayName}، ${_0x0a2b(gregDate)} (${iso})`;
}
function _0x0a31() {
 const s = document.getElementById('diffStart')?.value;
 const e = document.getElementById('diffEnd')?.value;
 if (!s || !e) return;
 const d1 = new Date(s + 'T00:00:00');
 const d2 = new Date(e + 'T00:00:00');
 const totalDays = Math.round(Math.abs(d2 - d1) / (1000 * 60 * 60 * 24));
 const years = Math.floor(totalDays / 365.25);
 const months = Math.floor((totalDays % 365.25) / 30.4375);
 const days = Math.round((totalDays % 365.25) % 30.4375);
 document.getElementById('diffResult').textContent =
 `${years} سنة و ${months} شهر و ${days} يوم (إجمالي ${totalDays} يوم)`;
}
const kofiSupportBtn = document.getElementById('kofiSupportBtn');
if (kofiSupportBtn) {
 kofiSupportBtn.addEventListener('click', (e) => {
 e.preventDefault();
 const url = 'https://ko-fi.com/D1D71L76R7';
 if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
 chrome.tabs.create({ url });
 } else {
 window.open(url, '_blank');
 }
 });
}
_0x0a20();
_0x0a28();
_0x0a2e();