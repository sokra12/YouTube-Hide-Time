/* Protected Build - Copyright (c) 2026 Sokra701s (Ko-fi: D1D71L76R7). All Rights Reserved. Unauthorized copying prohibited. */
const _0x0a10 = {
 masterEnabled: true,
 hideThumbnails: true,
 hidePlayerTime: true,
 hideProgressBar: false,
 hideHoverPreview: true,
 hideTimestamps: false,
 clockEnabled: false,
 clockTimezone: 'Asia/Riyadh',
 clockCountryName: 'السعودية - الرياض',
 clockDisplayMode: 'both', // 'time_only' | 'date_only' | 'both'
 clockCalendarType: 'hijri_greg', // 'hijri' | 'gregorian' | 'hijri_greg'
 clockShowCity: true,
 clockStyle: 'glass-pill', // 'glass-pill' | 'minimal' | 'stacked-card' | 'neon' | 'gold' | 'outline'
 clockScale: 100, // 65% to 200%
 clockOpacity: 35, // Background opacity: 0% (completely transparent) to 98%
 clockTextOpacity: 90, // Overall text/widget opacity: 15% to 100%
 clockFormat24: false,
 ytHideShorts: false,
 ytHideSidebar: false,
 ytHideComments: false,
 ytHideEndcards: false,
 ytRoundedThumbnails: false,
 ytGridCols: 'default',
 ytAccentColor: 'default',
 ytBgTheme: 'default'
};
let _0x0a17 = { ..._0x0a10 };
let _0x0a18 = null;
const _0x0a15 = /^\s*(\d{1,2}:)?\d{1,2}:\d{2}\s*$/;
function _0x0a19() {
 const isEnabled = _0x0a17.masterEnabled !== false && _0x0a17.hideThumbnails;
 if (!isEnabled) {
 document.querySelectorAll('[data-hvt-hidden-time="true"]').forEach(el => {
 el.removeAttribute('data-hvt-hidden-time');
 });
 return;
 }
 const candidates = document.querySelectorAll(
 'ytd-thumbnail-overlay-time-status-renderer, ' +
 'yt-thumbnail-badge-view-model, ' +
 'yt-thumbnail-bottom-overlay-view-model badge-shape, ' +
 'badge-shape, ' +
 '.badge-shape-wiz--thumbnail-badge, ' +
 '.yt-badge-shape--thumbnail-badge, ' +
 'span.ytd-thumbnail-overlay-time-status-renderer, ' +
 '#time-status, ' +
 '[aria-label*="دقيقة"], [aria-label*="ثانية"], [aria-label*="ساعة"], ' +
 '[aria-label*="minute"], [aria-label*="second"], [aria-label*="hour"]'
 );
 candidates.forEach(el => {
 const text = (el.textContent || '').trim();
 if (
 el.tagName.toLowerCase().includes('time-status') ||
 el.tagName.toLowerCase().includes('thumbnail-badge') ||
 el.id === 'time-status' ||
 _0x0a15.test(text)
 ) {
 el.setAttribute('data-hvt-hidden-time', 'true');
 }
 });
}
function _0x0a1a(now, tz, calType) {
 try {
 const hijriStr = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
 timeZone: tz,
 day: 'numeric',
 month: 'short',
 year: 'numeric'
 }).format(now);
 const gregStr = new Intl.DateTimeFormat('en-GB', {
 timeZone: tz,
 day: '2-digit',
 month: '2-digit',
 year: 'numeric'
 }).format(now);
 if (calType === 'hijri') return hijriStr;
 if (calType === 'gregorian') return gregStr;
 return `${hijriStr} • ${gregStr}`;
 } catch (e) {
 return now.toLocaleDateString();
 }
}
function _0x0a1b() {
 let overlay = document.getElementById('hvt-world-clock-overlay');
 if (!_0x0a17.clockEnabled) {
 if (overlay) overlay.remove();
 if (_0x0a18) {
 clearInterval(_0x0a18);
 _0x0a18 = null;
 }
 return;
 }
 if (!document.body) return;
 if (!overlay) {
 overlay = document.createElement('div');
 overlay.id = 'hvt-world-clock-overlay';
 document.body.appendChild(overlay);
 }
 const styleName = _0x0a17.clockStyle || 'glass-pill';
 overlay.className = `hvt-style-${styleName}`;
 const scale = Math.max(0.6, Math.min(2.2, (Number(_0x0a17.clockScale) || 100) / 100));
 const bgAlpha = Math.max(0, Math.min(0.98, (Number(_0x0a17.clockOpacity ?? 35)) / 100));
 const widgetOpacity = Math.max(0.15, Math.min(1, (Number(_0x0a17.clockTextOpacity ?? 90)) / 100));
 overlay.style.setProperty('--hvt-scale', String(scale));
 overlay.style.setProperty('--hvt-bg-alpha', String(bgAlpha));
 overlay.style.setProperty('--hvt-widget-opacity', String(widgetOpacity));
 const renderContent = () => {
 try {
 const now = new Date();
 const tz = _0x0a17.clockTimezone || 'Asia/Riyadh';
 const mode = _0x0a17.clockDisplayMode || 'both';
 const showCity = _0x0a17.clockShowCity !== false;
 const cityText = _0x0a17.clockCountryName || 'الرياض';
 const timeStr = new Intl.DateTimeFormat('en-US', {
 timeZone: tz,
 hour: '2-digit',
 minute: '2-digit',
 second: '2-digit',
 hour12: !_0x0a17.clockFormat24
 }).format(now);
 const dateStr = _0x0a1a(now, tz, _0x0a17.clockCalendarType || 'hijri_greg');
 const parts = [];
 if (showCity) {
 parts.push(`<span class="hvt-clock-city">${cityText}</span>`);
 }
 if (mode === 'time_only' || mode === 'both') {
 if (parts.length > 0) parts.push(`<span class="hvt-clock-sep">|</span>`);
 parts.push(`<span class="hvt-clock-time">${timeStr}</span>`);
 }
 if (mode === 'date_only' || mode === 'both') {
 if (parts.length > 0) parts.push(`<span class="hvt-clock-sep">|</span>`);
 parts.push(`<span class="hvt-clock-date">${dateStr}</span>`);
 }
 overlay.innerHTML = parts.join('');
 } catch (e) {
 overlay.textContent = new Date().toLocaleTimeString();
 }
 };
 renderContent();
 if (_0x0a18) clearInterval(_0x0a18);
 _0x0a18 = setInterval(renderContent, 1000);
}
function _0x0a1c(settings) {
 _0x0a17 = { ..._0x0a10, ...(settings || {}) };
 const root = document.documentElement;
 if (!root) return;
 const isEnabled = _0x0a17.masterEnabled !== false;
 root.classList.toggle('hvt-hide-thumbnails', Boolean(isEnabled && _0x0a17.hideThumbnails));
 root.classList.toggle('hvt-hide-player-time', Boolean(isEnabled && _0x0a17.hidePlayerTime));
 root.classList.toggle('hvt-hide-progress-bar', Boolean(isEnabled && _0x0a17.hideProgressBar));
 root.classList.toggle('hvt-hide-hover-preview', Boolean(isEnabled && _0x0a17.hideHoverPreview));
 root.classList.toggle('hvt-hide-timestamps', Boolean(isEnabled && _0x0a17.hideTimestamps));
 root.classList.toggle('hvt-yt-hide-shorts', Boolean(_0x0a17.ytHideShorts));
 root.classList.toggle('hvt-yt-hide-sidebar', Boolean(_0x0a17.ytHideSidebar));
 root.classList.toggle('hvt-yt-hide-comments', Boolean(_0x0a17.ytHideComments));
 root.classList.toggle('hvt-yt-hide-endcards', Boolean(_0x0a17.ytHideEndcards));
 root.classList.toggle('hvt-yt-rounded-thumbnails', Boolean(_0x0a17.ytRoundedThumbnails));
 if (_0x0a17.ytGridCols && _0x0a17.ytGridCols !== 'default') {
 root.classList.add('hvt-yt-grid-custom');
 root.style.setProperty('--hvt-grid-cols', _0x0a17.ytGridCols);
 } else {
 root.classList.remove('hvt-yt-grid-custom');
 root.style.removeProperty('--hvt-grid-cols');
 }
 if (_0x0a17.ytAccentColor && _0x0a17.ytAccentColor !== 'default') {
 root.classList.add('hvt-yt-custom-accent');
 root.style.setProperty('--hvt-yt-accent', _0x0a17.ytAccentColor);
 } else {
 root.classList.remove('hvt-yt-custom-accent');
 root.style.removeProperty('--hvt-yt-accent');
 }
 root.classList.remove('hvt-yt-bg-oled', 'hvt-yt-bg-midnight', 'hvt-yt-bg-emerald');
 if (_0x0a17.ytBgTheme && _0x0a17.ytBgTheme !== 'default') {
 root.classList.add(`hvt-yt-bg-${_0x0a17.ytBgTheme}`);
 }
 _0x0a19();
 if (document.body) {
 _0x0a1b();
 } else {
 window.addEventListener('DOMContentLoaded', () => _0x0a1b(), { once: true });
 }
}
const observer = new MutationObserver(() => {
 if (_0x0a17.masterEnabled !== false && _0x0a17.hideThumbnails) {
 _0x0a19();
 }
 if (_0x0a17.clockEnabled && document.body && !document.getElementById('hvt-world-clock-overlay')) {
 _0x0a1b();
 }
});
function _0x0a1d() {
 if (document.documentElement) {
 observer.observe(document.documentElement, {
 childList: true,
 subtree: true
 });
 }
}
_0x0a1d();
if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
 chrome.storage.sync.get(_0x0a10, (stored) => {
 _0x0a1c(stored || _0x0a10);
 });
 chrome.storage.onChanged.addListener((changes, areaName) => {
 if (areaName === 'sync' || areaName === 'local') {
 chrome.storage.sync.get(_0x0a10, (updated) => {
 _0x0a1c(updated || _0x0a10);
 });
 }
 });
} else {
 _0x0a1c(_0x0a10);
}